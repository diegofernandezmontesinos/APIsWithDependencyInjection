﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Servicio;
using shared;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonaController : ControllerBase
    {
        private readonly IPersonaService _personaServiceGlobal;
        public PersonaController(IPersonaService personaServiceDelConstructor)
        {
            _personaServiceGlobal = personaServiceDelConstructor;
        }


        [HttpPost("ingresar-body")]
        public IActionResult InsertarDesdeBody(PersonaDTO personaDTO)
        {
            _personaServiceGlobal.Insertar(personaDTO);
            return Ok("Todo ok");
        }

        [HttpGet("obtener-por-id/{id}")]
        public IActionResult GetPorId(int id)
        {
           return Ok(_personaServiceGlobal.ObtenerPorId(id));
        }

        [HttpDelete("borrar-por-id/{id}")]

        public IActionResult DeletePorId(int id)
        {
            var persona = _personaServiceGlobal.BorrarPorId(id);
            return Ok("persona " + persona + " ha sido borrada de la BBDD");
        }

        [HttpPut("actualizar-por-body")]

        public IActionResult ActualizarPorId(PersonaDTO persona)
        {
            var personaEnviar = _personaServiceGlobal.Actualizar(persona);
            return Ok("BBDD actualizada, tu nueo nombre es " + personaEnviar.Nombre + " y tu apellido es " + personaEnviar.Apellido);
        }
    }
}
