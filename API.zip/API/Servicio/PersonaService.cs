﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using shared;

namespace Servicio
{
    public class PersonaService: IPersonaService
    {
        public void Insertar(PersonaDTO personaDTO)
        {
            Persona p = new Persona();
            p.Nombre = personaDTO.Nombre;
            p.Apellido = personaDTO.Apellido;
            p.DNI = personaDTO.DNI;
            p.Id = personaDTO.Id;

            //mandar el objeto a insertar en la BBDD
        }

        public PersonaDTO ObtenerPorId(int id)
        {
            PersonaDTO p = new PersonaDTO();
            p.Nombre = "Thanos";
            p.Apellido = "Marxial";

            return p;
        }

        public PersonaDTO BorrarPorId(int id)
        {
            PersonaDTO p = new PersonaDTO();
            p.Nombre = "Thanos";
            p.Apellido = "Marxial";

            return p;
        }

        public PersonaDTO Actualizar(PersonaDTO persona) {
            PersonaDTO p = new PersonaDTO();
            p.Nombre = "Thoros";
            p.Apellido = "De Mir";

            return p;
        }
    }
}
