﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using shared;

namespace Servicio
{
    public interface IPersonaService
    {
        void Insertar(PersonaDTO personaDTO);

        PersonaDTO ObtenerPorId(int id);

        PersonaDTO BorrarPorId(int id);

        PersonaDTO Actualizar(PersonaDTO personaDTO);
    }
}
